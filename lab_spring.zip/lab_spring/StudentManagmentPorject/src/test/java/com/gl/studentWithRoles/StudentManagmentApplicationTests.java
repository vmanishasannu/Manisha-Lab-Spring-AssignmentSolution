package com.gl.studentWithRoles;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.gl.studentWithRoles.entity.Role;
import com.gl.studentWithRoles.entity.User;
import com.gl.studentWithRoles.repository.UserRepository;

@SpringBootTest
class StudentManagmentApplicationTests {
	@Autowired 
	UserRepository userRepository;
	
	@Test
	void contextLoads() {
		// here we set a encrypted passowrd for username in db
		//manisha manisha ADMIN
		//user1 pass	USER
		/*Role r=new Role();
		User u=new User();		
		BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
		String encoderValue=encoder.encode("pass");
		u.setPassword(encoderValue);
		System.out.println("Encoder Value: "+encoderValue);
		u.setUsername("user1");
		r.setName("USER");
		List<Role> lr=new ArrayList<>();
		lr.add(r);
		u.setRoles(lr);
		userRepository.save(u);*/
	}
	
}
