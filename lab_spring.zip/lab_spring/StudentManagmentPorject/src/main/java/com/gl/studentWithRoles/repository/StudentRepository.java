package com.gl.studentWithRoles.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.studentWithRoles.entity.StudentEntity;

public interface StudentRepository extends JpaRepository<StudentEntity, Integer> {

	List<StudentEntity> findByNameContainsAndDepartmentContainsAllIgnoreCase(String name,String department);
	
}
