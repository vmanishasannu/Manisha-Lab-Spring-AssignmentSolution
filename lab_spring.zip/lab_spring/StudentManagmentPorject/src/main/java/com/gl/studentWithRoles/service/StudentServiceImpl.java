package com.gl.studentWithRoles.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.studentWithRoles.entity.StudentEntity;
import com.gl.studentWithRoles.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	StudentRepository studentRepository;
	
	@Override
	public List<StudentEntity> findAll() {
		List<StudentEntity> student=studentRepository.findAll();
		return student;
	}

	@Override
	public StudentEntity findById(int theId) {
		return studentRepository.findById(theId).get();
	}

	@Override
	public void save(StudentEntity student) {
		studentRepository.save(student);
		
	}

	@Override
	public void deleteById(int theId) {
		studentRepository.deleteById(theId);
		
	}
	@Override
	public List<StudentEntity> searchBy(String name, String department) {
		// TODO Auto-generated method stub
		List<StudentEntity> student=studentRepository.findByNameContainsAndDepartmentContainsAllIgnoreCase(name, department);
		return student;
	}
}
