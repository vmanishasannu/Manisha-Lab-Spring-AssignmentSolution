package com.gl.studentWithRoles.service;

import java.util.List;

import com.gl.studentWithRoles.entity.StudentEntity;

public interface StudentService{
	public List<StudentEntity> findAll();

	public StudentEntity findById(int theId);

	public void save(StudentEntity theBook);

	public void deleteById(int theId);
	
	public List<StudentEntity> searchBy(String name, String department);

}